package com.cg.obs.service;


import java.util.List;

import com.cg.obs.bean.Admin;
import com.cg.obs.bean.Customer;
import com.cg.obs.bean.ServiceTracker;
import com.cg.obs.bean.Transactions;
import com.cg.obs.bean.Users;
import com.cg.obs.dao.AdminDaoImpl;
import com.cg.obs.dao.IAdminDao;
import com.cg.obs.dao.IUserDAO;
import com.cg.obs.dao.UserDAOImpl;
import com.cg.obs.exception.UserException;

public class UserServiceImpl implements IUserService {

	IUserDAO userDao;
	IAdminDao adminDao;
	public UserServiceImpl() {
		userDao=new UserDAOImpl();
		adminDao=new AdminDaoImpl();
	}
	
	
	
	@Override
	public Users getUser(int id) throws UserException {
		
		return userDao.getUser(id);
	}

	@Override
	public Admin getAdmin(String id) throws UserException {
		
		return adminDao.getAdmin(id);
	}



	@Override
	public List<Transactions> getMiniTransactions(Long accountno) throws UserException {
		
		return userDao.getMiniTransactions(accountno);
	}

	
	@Override
	public List<Transactions> getDetailedTransactions(Long accountno) throws UserException {

		return userDao.getDetailedTransactions(accountno);
	}



	@Override
	public void updateCustomerDetails(Customer customer) throws UserException {
	
		userDao.updateCustomerDetails(customer);
	}


	@Override
	public int requestService(ServiceTracker services) throws UserException {
		
		return userDao.requestService(services);
	}

}
